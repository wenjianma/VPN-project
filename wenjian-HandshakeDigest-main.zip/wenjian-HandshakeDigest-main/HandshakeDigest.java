public class HandshakeDigest {

    /*
     * Constructor -- initialise a digest for SHA-256
     */

    public HandshakeDigest() {
    }

    /*
     * Update digest with input data
     */
    public void update(byte[] input) {
    }

    /*
     * Compute final digest
     */
    public byte[] digest() {
        return new byte[0];
    }
};
