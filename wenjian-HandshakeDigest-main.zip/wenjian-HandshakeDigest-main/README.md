# Files for SessionCipher Assignment

- `README.md` This file. It is in in Markdown format. You can view it as a text file, or use a Markdown preview tool (there are plenty). 
- `HandshakeDigest.java` is a skeleton file for your implementation. This is where you write your code!
- `FileDigest.java` is a skeleton file for your program.
- `input.txt`is a sample plaintext file.
- `digest.txt` contains the Base-64 encoded digest for `input.txt`.


