public class FileDigest {
    public static void main(String[] args) {
    }
}
